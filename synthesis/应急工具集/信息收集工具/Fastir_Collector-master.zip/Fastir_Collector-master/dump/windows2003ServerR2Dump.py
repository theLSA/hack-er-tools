from __future__ import unicode_literals
from dump import _Dump


class Windows2003ServerR2Dump(_Dump):
    def __init__(self, params):
        super(Windows2003ServerR2Dump, self).__init__(params)
