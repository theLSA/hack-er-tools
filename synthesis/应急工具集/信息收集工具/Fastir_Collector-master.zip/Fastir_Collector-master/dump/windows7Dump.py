from __future__ import unicode_literals
from dump import _Dump


class Windows7Dump(_Dump):
    def __init__(self, params):
        super(Windows7Dump, self).__init__(params)
