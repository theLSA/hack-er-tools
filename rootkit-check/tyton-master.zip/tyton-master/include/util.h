#ifndef UTIL_H
#define UTIL_H

struct module *get_module_from_addr(unsigned long);

#endif /* UTIL_H */
