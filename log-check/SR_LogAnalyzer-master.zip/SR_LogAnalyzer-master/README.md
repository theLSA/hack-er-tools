# SR_LogAnalyzer

#### Description 介绍
Automatically analysis logs and find the intrusion when we do Security Response.  
辅助网络安全应急响应，自动化的分析日志，找出入侵行为。  

#### Warning 警告  
Please follow the 《Cybersecurity Law of the People's Republic of China》. DO NOT use it for any unauthorized testing. I will not be responsible for it.  
请使用者遵守《中华人民共和国网络安全法》，勿用于非授权的测试，本人不负任何连带法律责任。

#### Attention 注意  
The project is still under construction  
项目仍在建设中

#### Instructions 使用说明  
