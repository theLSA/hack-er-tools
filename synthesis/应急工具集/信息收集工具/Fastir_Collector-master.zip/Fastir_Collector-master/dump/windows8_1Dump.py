from __future__ import unicode_literals
from dump import _Dump


class Windows8_1Dump(_Dump):
    def __init__(self, params):
        super(Windows8_1Dump, self).__init__(params)
