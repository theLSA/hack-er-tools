#ifndef SYSCALL_HOOKS_H
#define SYSCALL_HOOKS_H

void analyze_syscalls(void);

#endif /* SYSCALL_HOOKS_H */
