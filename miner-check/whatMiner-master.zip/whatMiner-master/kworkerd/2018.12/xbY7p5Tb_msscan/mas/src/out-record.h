#ifndef OUT_RECORD_H
#define OUT_RECORD_H

enum OutputRecordType {
    Out_Open = 1,
    Out_Closed = 2,
    Out_Banner1 = 5,
    Out_Open2 = 6,
    Out_Closed2 = 7,
    Out_Arp2 = 8,
    Out_Banner9 = 9,
};
#endif
