# windows-应急服务辅助工具
windows下一款可视化，一键检测辅助应急工具，生成数据采集、关联报告。

![image](https://github.com/TimelifeCzy/windows-emergency-servicetools/blob/master/1.jpg)

#### 关联分析：规则链
&emsp;&emsp;1. 自启动 --> 进程 pid --> 网络端口 --> 本地文件

&emsp;&emsp;2. 进程 pid --> 网络端口  --> 自启动 --> 文件

**这是一种基于数据采集，组织规则关联分析或说模糊匹配，而并不是针对病毒查杀工具，后续待更。** 

**工具思路讲解：**
https://bbs.pediy.com/thread-256740.htm

内存取证辅助分析工具后续也会更新：https://github.com/TimelifeCzy/Windows-Monitor-and-Memory-forensics
