from __future__ import unicode_literals
from dump import _Dump


class Windows2012ServerR2Dump(_Dump):
    def __init__(self, params):
        super(Windows2012ServerR2Dump, self).__init__(params)
