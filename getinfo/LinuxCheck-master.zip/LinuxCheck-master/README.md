# LinuxCheck

###
一个linux信息搜集小脚本 主要用于应急响应
### Usage
apt-get install silversearcher-ag

bash -c "$(curl -sSL https://raw.githubusercontent.com/al0ne/LinuxCheck/master/LinuxCheck.sh)"

### 参考

Linenum

https://github.com/lis912/Evaluation_tools

https://ixyzero.com/blog/archives/4.html
