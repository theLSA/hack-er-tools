#!/bin/bash
pip uninstall okcat --yes
python setup.py install
