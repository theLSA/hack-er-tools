#!/usr/bin/python
# -*- coding: UTF-8 -*-

def main():
    pass

if __name__ == "__main__":
    main()