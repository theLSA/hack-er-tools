from __future__ import unicode_literals
from dump import _Dump


class WindowsXPDump(_Dump):
    def __init__(self, params):
        super(WindowsXPDump, self).__init__(params)
