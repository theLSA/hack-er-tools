int hexagon_anal_instruction(HexInsn *hi, RAnalOp *op);

