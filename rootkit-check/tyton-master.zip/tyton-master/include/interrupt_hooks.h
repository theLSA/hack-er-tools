#ifndef INTERRUPT_HOOKS_H
#define INTERRUPT_HOOKS_H

void analyze_interrupts(void);

#endif /* INTERRUPT_HOOKS_H */
