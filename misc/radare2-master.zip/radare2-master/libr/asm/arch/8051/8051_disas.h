#ifndef R2_8051_DISAS_H
#define R2_8051_DISAS_H

int _8051_disas (ut64 pc, RAsmOp *op, const ut8 *buf, ut64 len);

#endif
