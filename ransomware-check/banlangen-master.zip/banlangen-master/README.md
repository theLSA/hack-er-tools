## banlangen
banlangen(板蓝根)是一个用基于注册表，用于免疫WannaCrypt勒索蠕虫的小脚本，该项目会持续跟进更新，如果帮助到了您，请麻烦你给个star哈~

使用时请右键使用管理员权限运行start.bat即可。（如果在某些系统中提示无法导入banlangen.reg，直接右键以管理员权限重新运行banlangen.reg即可）
