datas = [('winpmem_x64.sys', ''),
         ('winpmem_x86.sys', ''),
         ('Rekall_x64', ''),
         ('Rekall_x86', ''),
         ('msvcr100.dll', 'DLLs')]