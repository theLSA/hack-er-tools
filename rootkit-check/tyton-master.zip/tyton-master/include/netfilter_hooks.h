#ifndef NETFILTER_HOOKS_H
#define NETFILTER_HOOKS_H

int analyze_netfilter(void);

#endif /* NETFILTER_HOOKS_H */
