#ifndef CORE_H
#define CORE_H

#include <linux/kernel.h>
#include <linux/module.h>
#include <linux/version.h>

#endif /* CORE_H */
