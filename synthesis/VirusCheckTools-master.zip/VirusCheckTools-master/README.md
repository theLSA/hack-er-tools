# VirusCheckTools
基于行为特征进行快速匹配病毒专杀工具，辅助应急响应

WanncryScan.cpp 针对勒索Wanncry进程检测查杀，主进程释放检测

MiningVirusKillTools.zip 挖矿检测辅助工具，图形化CPU实时监控，黑白名单功能，对单线程性能占用检测

 
