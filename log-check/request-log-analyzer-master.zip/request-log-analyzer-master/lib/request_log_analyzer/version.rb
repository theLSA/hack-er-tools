module RequestLogAnalyzer
  VERSION = '1.13.4'
end
